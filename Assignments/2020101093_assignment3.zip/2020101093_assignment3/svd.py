# Installation
# %pip install torch
# %pip install torchtext
# !unzip colab.zip
# Import
import torch
torch.manual_seed(42) # Set Seed for reproducibility
import csv
import numpy as np
import pandas as pd
from nltk import RegexpTokenizer
import re
from torchtext.vocab import Vocab
from torch.utils.data import DataLoader, Dataset
from numpy.linalg import norm
import scipy as sp
sizeOfTrainData = int(0.2*120000)
# Data
def getDescriptions(csvFilePath, numOfRows):
    df = pd.read_csv(csvFilePath, nrows=numOfRows, usecols=['Description'])
    # print(df.shape)
    # df.head()
    textData = df['Description']
    return textData
# Dataset
UNKNOWN_TOKEN = "<UNK>"
NUMBER_TOKEN = "<NUM>"
START_TOKEN = "<START>"
END_TOKEN = "<END>"
PAD_TOKEN = "<PAD>"
class embedDataset(Dataset):
    def __init__(self, data : list[str], wordVocab:Vocab|None = None):
        self.data = data
        self.wordVocab = wordVocab
        # if wordVocab is None:
        #     print("wordVocab needs to be provided")
        #     exit(1)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        des =  self.tokenize(self.data[idx])
        if self.wordVocab is not None:
            return torch.tensor(self.wordVocab.lookup_indices(des), dtype=torch.long)

    def tokenize(self, des:str):
        des = des.lower()
        tokDes = RegexpTokenizer(r'\w+').tokenize(des)
        # add start and end token
        tokDes = [START_TOKEN] + tokDes + [END_TOKEN]
        # replace numbers with <NUM>
        tokDes = [re.sub(r'\d+', NUMBER_TOKEN, word) for word in tokDes]
        return tokDes

# word2vec using SVD
class SVDword2vec(torch.nn.Module):
    def __init__(self, dataset: embedDataset, windowSize: int, wordVocab: Vocab, embeddingSize:int|None = None):
        super().__init__()
        self.dataset = dataset
        self.windowSize = windowSize
        self.embeddingSize = embeddingSize
        self.wordVocab = wordVocab
        self.coOccurrenceMatrix = np.zeros((len(self.wordVocab), len(self.wordVocab)))
        self.minVariance = 0.95
        self.vectors = None
        self.minEmbeddingSize = 100


    def createCoOccurrenceMatrix(self):
        for i in range(len(self.dataset)):
            for j in range(len(self.dataset[i])):
                window = self.dataset[i][max(0, j - self.windowSize):min(len(self.dataset[i]), j + self.windowSize + 1)]
                word = self.dataset[i][j]
                for k in range(len(window)):
                    if window[k] != word:
                        self.coOccurrenceMatrix[word.item(), window[k].item()] += 1
        return

    def train(self):
        self.createCoOccurrenceMatrix()
        U, S, Vt = sp.sparse.linalg.svds(self.coOccurrenceMatrix)
        den = sum(S)
        c_sum = 0
        if self.embeddingSize is None:
            for i, x in enumerate(S):
                c_sum = c_sum + x
                if (c_sum/den > self.minVariance):
                    self.embeddingSize = i+1
                    break
        if self.embeddingSize < self.minEmbeddingSize :
          self.embeddingSize = self.minEmbeddingSize
        self.vectors = U[:, :self.embeddingSize]
        self.vectors = np.array([v/norm(v) for v in self.vectors])
        return
# load Vocab
wordVocab = torch.load("trainWordVocab"+str(sizeOfTrainData)+".pth")
print("Vocab size: ", len(wordVocab))
# train dataset
trainData = getDescriptions('./data/train.csv', sizeOfTrainData)
print(trainData[:5])
trainDataset = embedDataset(trainData, wordVocab)
print(trainDataset[6])
# Train
device = "cuda" if torch.cuda.is_available() else "cpu"
print(device)
# def saveSVDword2vec(model: SVDword2vec):
#     modelPath = f"svd_{sizeOfTrainData}_{model.windowSize}_{model.embeddingSize}.pt"
#     torch.save(model, modelPath)
#     print(f"Model saved at {modelPath}")
#     return
windowSize = 3
# trainDataset = trainDataset.to(device)
mySVDword2vec = SVDword2vec(trainDataset,windowSize,wordVocab).to(device)
mySVDword2vec.train()
print("model training done")
# mySVDword2vec.saveVectors()
# saveSVDword2vec(mySVDword2vec)
vectorsPath = f"svd_{sizeOfTrainData}_{mySVDword2vec.windowSize}_{mySVDword2vec.embeddingSize}.pt"
torch.save(mySVDword2vec.vectors, vectorsPath)
print(f"vectors saved at {vectorsPath}")
print("vectors shape", mySVDword2vec.vectors.shape)