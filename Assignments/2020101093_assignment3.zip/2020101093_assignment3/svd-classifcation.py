# Installation
# %pip install torch
# %pip install torchtext
# !unzip colab.zip
# Imports
import torch
torch.manual_seed(42) # Set Seed for reproducibility
import csv
import numpy as np
import pandas as pd
from nltk import RegexpTokenizer
import re
from torchtext.vocab import Vocab
from torch.utils.data import DataLoader, Dataset
from numpy.linalg import norm
import scipy as sp
from torch.nn.utils.rnn import pad_sequence

sizeOfTrainData = int(0.2*120000)
# Data
def getData(csvFilePath, numOfRows=None):
    if numOfRows is None:
        df = pd.read_csv(csvFilePath)
    else:
        df = pd.read_csv(csvFilePath, nrows=numOfRows)
    # print(df.shape)
    # df.head()
    data = np.array(df)
    # for i in range(0, data.shape[0]):
    #     data[i] = tuple(data[i])
    # print(data.shape)
    # print(data[0:5])
    # print(type(data[0][0]))
    # print(type(data[0][1]))
    return data
# getData('./data/train.csv', sizeOfTrainData)
# Dataset
UNKNOWN_TOKEN = "<UNK>"
NUMBER_TOKEN = "<NUM>"
START_TOKEN = "<START>"
END_TOKEN = "<END>"
PAD_TOKEN = "<PAD>"

class classificationDataset(Dataset):
    def __init__(self, data : list[list[int , str]], wordVocab:Vocab|None = None , labelVocab:Vocab|None = None):
        self.data = data
        self.wordVocab = wordVocab
        self.labelVocab = labelVocab

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx) ->tuple[torch.Tensor, torch.Tensor]:
        label, des = self.data[idx]
        label = str(label)
        des = self.tokenize(des)
        if self.wordVocab is not None:
            return torch.tensor(self.wordVocab.lookup_indices(des), dtype=torch.long), torch.tensor(self.labelVocab.lookup_indices([label]), dtype=torch.long)

    def tokenize(self, des:str):
        des = des.lower()
        tokDes = RegexpTokenizer(r'\w+').tokenize(des)
        # add start and end token
        tokDes = [START_TOKEN] + tokDes + [END_TOKEN]
        # replace numbers with <NUM>
        tokDes = [re.sub(r'\d+', NUMBER_TOKEN, word) for word in tokDes]
        return tokDes

    def collate(self, batch: list[tuple[torch.Tensor, torch.Tensor]])-> tuple[torch.Tensor, torch.Tensor]:
        """Given a list of datapoints, batch them together"""
        descriptions = [d[0] for d in batch]
        labels = [d[1] for d in batch]
        # descTensor = torch.tensor(descriptions, dtype = torch.long)
        padded_descriptions = pad_sequence(descriptions, batch_first=True, padding_value = self.wordVocab[PAD_TOKEN]) # pad the descriptions with the PAD token ID to make them the same length
        # labels = torch.cat(labels)
        return padded_descriptions, torch.tensor(labels, dtype=torch.long)


# RNN classifier (many-to-one)
class RNN(torch.nn.Module):
    def __init__(self,emdeddings, hiddenDim, numLayers, classVocabSize, activation: torch.nn.Module ,dropout=0.0):
        super().__init__()
        self.hiddenDim = hiddenDim
        self.numLayers = numLayers
        self.numClasses = classVocabSize
        self.activationFun = activation
        self.preTrainedEmbeddings = torch.tensor(emdeddings)
        self.embeddingDim = self.preTrainedEmbeddings.shape[1]
        self.dropout = dropout
        self.embeddingModule = torch.nn.Embedding.from_pretrained(self.preTrainedEmbeddings,freeze=True)
        self.rnn = torch.nn.RNN(self.embeddingDim, self.hiddenDim, self.numLayers, batch_first=True , nonlinearity=self.activationFun, dropout=self.dropout)
        # self.dropout = torch.nn.Dropout(self.dropout)
        self.fc = torch.nn.Linear(self.hiddenDim, self.numClasses)

    def forward(self, sentences: torch.Tensor):
        # sentences = self.dropout(self.embeddingModule(sentences))
        emdeddings = self.embeddingModule(sentences)
        # print(sentences.shape)
        floatEmbeddings = emdeddings.detach().clone()
        floatEmbeddings = floatEmbeddings.float() # converting to torch.float32
        out, _ = self.rnn(floatEmbeddings)
        # print(out.shape)
        # many to one
        # print(out[:,-1,:].shape)
        out = self.fc(out[:,-1,:])
        # reshape the output to be 2D
        out = out.view(len(sentences), self.numClasses)
        # apply softmax to get the class probabilities
        out = torch.nn.functional.log_softmax(out, dim=1)
        return out
# load Vocab
wordVocab = torch.load("trainWordVocab"+str(sizeOfTrainData)+".pth")
print("word Vocab size: ", len(wordVocab))
classVocab = torch.load("trainClassVocab"+str(sizeOfTrainData)+".pth")
print("tag Vocab size: ", len(classVocab))
# create datasets & dataloaders
trainData = getData('./data/train.csv', sizeOfTrainData)
print(trainData[:5])
trainDataset = classificationDataset(trainData, wordVocab, classVocab)
print(trainDataset[6])
batchSize = 64
trainDataloader = DataLoader(trainDataset, batch_size=batchSize, shuffle=True, collate_fn=trainDataset.collate)
valData = getData('./data/val.csv')
valDataset = classificationDataset(valData,wordVocab, classVocab)
valDataloader = DataLoader(valDataset, batch_size=batchSize, shuffle=False, collate_fn=valDataset.collate)
print(valDataset[0])
# load Embeddings
UNKNOWN_TOKEN = "<UNK>"
NUMBER_TOKEN = "<NUM>"
START_TOKEN = "<START>"
END_TOKEN = "<END>"
PAD_TOKEN = "<PAD>"
class embedDataset(Dataset):
    def __init__(self, data : list[str], wordVocab:Vocab|None = None):
        self.data = data
        self.wordVocab = wordVocab
        # if wordVocab is None:
        #     print("wordVocab needs to be provided")
        #     exit(1)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        des =  self.tokenize(self.data[idx])
        if self.wordVocab is not None:
            return torch.tensor(self.wordVocab.lookup_indices(des), dtype=torch.long)

    def tokenize(self, des:str):
        des = des.lower()
        tokDes = RegexpTokenizer(r'\w+').tokenize(des)
        # add start and end token
        tokDes = [START_TOKEN] + tokDes + [END_TOKEN]
        # replace numbers with <NUM>
        tokDes = [re.sub(r'\d+', NUMBER_TOKEN, word) for word in tokDes]
        return tokDes

class SVDword2vec(torch.nn.Module):
    def __init__(self, dataset: embedDataset, windowSize: int, wordVocab: Vocab, embeddingSize:int|None = None):
        super().__init__()
        self.dataset = dataset
        self.windowSize = windowSize
        self.embeddingSize = embeddingSize
        self.wordVocab = wordVocab
        self.coOccurrenceMatrix = np.zeros((len(self.wordVocab), len(self.wordVocab)))
        self.minVariance = 0.95
        self.vectors = None
        self.minEmbeddingSize = 100


    def createCoOccurrenceMatrix(self):
        for i in range(len(self.dataset)):
            for j in range(len(self.dataset[i])):
                window = self.dataset[i][max(0, j - self.windowSize):min(len(self.dataset[i]), j + self.windowSize + 1)]
                word = self.dataset[i][j]
                for k in range(len(window)):
                    if window[k] != word:
                        self.coOccurrenceMatrix[word.item(), window[k].item()] += 1
        return

    def train(self):
        self.createCoOccurrenceMatrix()
        U, S, Vt = sp.sparse.linalg.svds(self.coOccurrenceMatrix)
        den = sum(S)
        c_sum = 0
        if self.embeddingSize is None:
            for i, x in enumerate(S):
                c_sum = c_sum + x
                if (c_sum/den > self.minVariance):
                    self.embeddingSize = i+1
                    break
        if self.embeddingSize < self.minEmbeddingSize :
          self.embeddingSize = self.minEmbeddingSize
        self.vectors = U[:, :self.embeddingSize]
        self.vectors = np.array([v/norm(v) for v in self.vectors])
        return
svdVecPath = "svd_96000_3_100.pt"
svdVec = torch.load(svdVecPath)
print(svdVec.shape)
hiddenDim = 50
numLayers = 2
activation = 'tanh'
learningRate = 0.001
numEpochs = 10
# Train
device = "cuda" if torch.cuda.is_available() else "cpu"
print(device)
myClassifier = RNN(svdVec, hiddenDim, numLayers,len(classVocab) , activation)
lossFn = torch.nn.NLLLoss()
optimizer = torch.optim.Adam(myClassifier.parameters(), lr=learningRate)

# send the model to the device
myClassifier = myClassifier.to(device)

# Train the model
for epochNum in range(numEpochs):
    myClassifier.train()
    for batchNum, (inputs, targets) in enumerate(trainDataloader):
        # Zero the gradients
        optimizer.zero_grad()

        # Move the data to the device
        inputs = inputs.to(device)
        targets = targets.to(device)

        # Forward pass
        preds = myClassifier(inputs)
        print("pred probs", preds)
        print("targets", targets)
        loss = lossFn(preds, targets)

        # Backward pass and update
        loss.backward()
        optimizer.step()

        if batchNum % 100 == 0:
            print('Epoch: ', epochNum, ', Batch: ', batchNum, ', Loss: ', loss.item())

    # Evaluate the model on the validation set
    myClassifier.eval()
    numCorrect = 0
    numTotal = 0
    evalLoss = 0
    # turn off gradients
    with torch.no_grad():
        for batchNum , (inputs, targets) in enumerate(valDataloader):
            # Move the data to the device
            inputs = inputs.to(device)
            targets = targets.to(device)
            # Forward pass
            preds = myClassifier(inputs)
            print("pred probs", preds)
            loss = lossFn(preds, targets)
            evalLoss += loss.item()
            # Get the predictions
            preds = torch.argmax(preds, axis=1)
            print("preds", preds)
            print("targets", targets)
            numCorrect += torch.sum(preds == targets).item()
            numTotal += len(targets)
    print('Epoch: ', epochNum, ', Validation Accuracy: ', numCorrect / numTotal, ', Validation Loss: ', evalLoss / numTotal)

# Save the model
classifierPath = f"rnn_{sizeOfTrainData}_{hiddenDim}_{numLayers}_{activation}_{learningRate}_{numEpochs}.pt"
torch.save(myClassifier, classifierPath)

# test
testData = getData("./data/test.csv")
testDataset = classificationDataset(testData,wordVocab, classVocab)
testDataloader = DataLoader(testDataset, batch_size=batchSize, shuffle=False, collate_fn= testDataset.collate)
loadedClassifier = torch.load(classifierPath)
# move the model to the GPU
loadedClassifier = loadedClassifier.to(device)
loadedClassifier.eval()
lossFn = torch.nn.NLLLoss()
testLoss = 0.0
correct = 0
total = 0
with torch.no_grad():
    for batchNum, (inputs, targets) in enumerate(testDataloader):
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = loadedClassifier(inputs)
        loss = lossFn(outputs, targets)
        print("output prob", outputs)
        testLoss += loss.item()
        predicted = torch.argmax(outputs, dim=1)
        print("predictions", predicted)
        print("targets", targets)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
# Print test Loss and Accuracy
print(f'test Loss: {testLoss/len(testDataloader)}, Test Accuracy: {(correct/total)*100} %')