# How to load models?
1. Download the models from the following link:

[models](https://iiitaphyd-my.sharepoint.com/:f:/g/personal/jujjuru_ruchitha_students_iiit_ac_in/EhcIxDjlGcVCghNPzqwMbDwBZQjusthKzN8YWqTEo6fStg?e=02D3Lv)


# How to execute?
```
python3 pos_tagger.py [-f|-r]
```
1. -f: Forward POS tagging
2. -r: LSTM POS tagging
