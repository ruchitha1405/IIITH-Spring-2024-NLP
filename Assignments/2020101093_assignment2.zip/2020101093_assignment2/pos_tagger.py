# %pip install nltk
import sys
from nltk.tokenize import RegexpTokenizer
# from ffn import PosDataset as ffnDataset
# from lstm import PosDataset as lstmDataset
# import json
import torch
# import conllu
# from io import open
from torch.utils.data import Dataset
from torchtext.vocab import build_vocab_from_iterator, Vocab
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader
import csv
import torch.nn.functional as F

bestLSTMModel = "lstmConfig2.pt"
bestFFNModel = "ffnDiffConf1.pt"

START_TOKEN = "<s>"
END_TOKEN = "</s>"
UNKNOWN_TOKEN = "<unk>"
PAD_TOKEN = "<pad>"
SPECIAL_TOKENS = [START_TOKEN, END_TOKEN, UNKNOWN_TOKEN, PAD_TOKEN]
UNK_POS_TAG = "UNKTAG"
SPECIAL_POS_TAG = "SPECIAL"

class lstmDataset(Dataset):
    def __init__(self, data : list[tuple[list[str], list[str]]] , wordVocabulary:Vocab|None=None , tagVocabulary:Vocab|None=None):
        """Initialize the dataset. Setup Code goes here"""
        self.sentences = [i[0] for i in data] # list of sentences
        self.labels = [i[1] for i in data] # list of labels
        if wordVocabulary is None:
            sentences = [i[0] for i in data] # list of sentences
            self.wordVocabulary = build_vocab_from_iterator(sentences, specials= SPECIAL_TOKENS, min_freq= 2) # use min_freq for handling unkown words better
            self.wordVocabulary.set_default_index(self.wordVocabulary[UNKNOWN_TOKEN])
        else:
            # if vocabulary provided use that
            self.wordVocabulary = wordVocabulary
        if tagVocabulary is None:
            self.tagVocabulary = build_vocab_from_iterator(self.labels, specials= [UNK_POS_TAG,SPECIAL_POS_TAG]) 
            self.tagVocabulary.set_default_index(self.tagVocabulary[UNK_POS_TAG]) # index for unknown tags 
        else:
            # if vocabulary provided use that
            self.tagVocabulary = tagVocabulary

    def __len__(self) -> int:
        """Returns number of datapoints."""
        return len(self.sentences)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Get the datapoint at `index`."""
        return torch.tensor(self.wordVocabulary.lookup_indices(self.sentences[index])), torch.tensor(self.tagVocabulary.lookup_indices(self.labels[index]))
    
    def createCSV(self, filename: str):
        # create a csv file with the chunks and labels to test if the dataset is created correctly
        with open(filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["chunks", "labels"])
            for i in range(len(self.sentences)):
                writer.writerow([self.sentences[i], self.labels[i]])

    def collate(self, batch: list[tuple[torch.Tensor, torch.Tensor]]) -> tuple[torch.Tensor, torch.Tensor]:
        """Given a list of datapoints, batch them together"""
        sentences = [i[0] for i in batch]
        labels = [i[1] for i in batch]
        padded_sentences = pad_sequence(sentences, batch_first=True, padding_value=self.wordVocabulary[PAD_TOKEN]) # pad sentences with pad token id
        padded_labels = pad_sequence(labels, batch_first=True, padding_value= self.tagVocabulary[SPECIAL_POS_TAG]) # pad labels with special_posTag
        return padded_sentences, padded_labels


class ffnDataset(Dataset):
    def __init__(self, data: list[tuple[list[str], list[str]]], pOfNN: int, sOfNN: int, wordVocabulary: Vocab | None = None, tagVocabulary: Vocab | None = None):
        """Initialize the dataset. Setup Code goes here"""
        self.pOfNN = pOfNN
        self.sOfNN = sOfNN
        self.chunks = []
        for i in range(len(data)):
            sentence = self.insertStartEndTokens(data[i][0])
            chunksList = [sentence[i: i+pOfNN+sOfNN+1]
                          for i in range(len(sentence)-pOfNN-sOfNN)]
            self.chunks.extend(chunksList)
        self.labels = []
        for i in range(len(data)):
            sentenceTags = data[i][1]
            self.labels.extend(sentenceTags)

        if wordVocabulary is None:
            sentences = [i[0] for i in data]  # list of sentences
            # use min_freq for handling unkown words better
            self.wordVocabulary = build_vocab_from_iterator(
                sentences, specials=SPECIAL_TOKENS, min_freq=2)
            self.wordVocabulary.set_default_index(
                self.wordVocabulary[UNKNOWN_TOKEN])
        else:
            # if vocabulary provided use that
            self.wordVocabulary = wordVocabulary
        if tagVocabulary is None:
            self.tagVocabulary = build_vocab_from_iterator(
                [self.labels], specials=[SPECIAL_POS_TAG])
            self.tagVocabulary.set_default_index(
                self.tagVocabulary[SPECIAL_POS_TAG])  # index for unknown tags
        else:
            # if vocabulary provided use that
            self.tagVocabulary = tagVocabulary

    def __len__(self) -> int:
        """Returns number of datapoints."""
        return len(self.chunks)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        """Get the datapoint at `index`."""
        posTagIndex = self.tagVocabulary[self.labels[index]]
        posTagVector = posTagIndex  # not converting to vector
        return torch.tensor(self.wordVocabulary.lookup_indices(self.chunks[index])), torch.tensor(posTagVector)

    def insertStartEndTokens(self, sentence: list[str]) -> list[str]:
        """Add start and end tokens to the sentence"""
        return [START_TOKEN]*self.pOfNN + sentence + [END_TOKEN]*self.sOfNN

    def createCSV(self, filename: str):
        # create a csv file with the chunks and labels to test if the dataset is created correctly
        with open(filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["chunks", "labels"])
            for i in range(len(self.chunks)):
                writer.writerow([self.chunks[i], self.labels[i]])

    def collate(self, batch: list[tuple[torch.Tensor, torch.Tensor]]) -> tuple[torch.Tensor, torch.Tensor]:
        pass

class FFN(torch.nn.Module):
    def __init__(self, vocabularySize: int, embeddingSize: int, p: int, s: int, tagVocabSize: int, activationFunction: torch.nn.Module, hiddenLayerSizes: list[int] = []):
        super(FFN, self).__init__()
        self.embeddingModule = torch.nn.Embedding(
            vocabularySize, embeddingSize)
        # self.embeddingModule = torch.nn.Embedding.from_pretrained(pretrainedEmbeddings)
        # self.embeddingModule.weight.requires_grad = False
        self.p = p
        self.s = s
        self.numOfInputWords = p + s + 1
        self.inputSize = embeddingSize*self.numOfInputWords
        self.outputSize = tagVocabSize
        self.hiddenLayerSizes = hiddenLayerSizes
        moduleList = []
        for i in range(len(self.hiddenLayerSizes)):
            if i == 0:
                moduleList.append(torch.nn.Linear(
                    self.inputSize, self.hiddenLayerSizes[i]))
            else:
                moduleList.append(torch.nn.Linear(
                    self.hiddenLayerSizes[i-1], self.hiddenLayerSizes[i]))
            moduleList.append(activationFunction)
        moduleList.append(torch.nn.Linear(
            self.hiddenLayerSizes[-1], self.outputSize))
        self.posTagger = torch.nn.Sequential(*moduleList)

    # wordIndices is a tensor of indices of words in the chunk
    def forward(self, wordIndices: torch.tensor):
        wordEmbeddings = self.embeddingModule(wordIndices)
        wordEmbeddings = wordEmbeddings.view(wordEmbeddings.size(0), -1)
        return self.posTagger(wordEmbeddings)


class LSTM(torch.nn.Module):
    def __init__(self, wordVocabularySize: int, embeddingSize: int, hiddenDim: int, tagVocabSize: int, numLayers: int) -> None:
        super().__init__()
        self.embeddingSize = embeddingSize
        self.hiddenDim = hiddenDim
        self.numLayers = numLayers
        self.wordVocabularySize = wordVocabularySize
        self.embeddingModule = torch.nn.Embedding(wordVocabularySize, embeddingSize)
        # self.embeddingModule = torch.nn.Embedding.from_pretrained(pretrainedEmbeddings)
        # self.embeddingModule.weight.requires_grad = False
        self.lstm = torch.nn.LSTM(self.embeddingSize,self.hiddenDim,self.numLayers)
        self.outputSize = tagVocabSize
        self.finalModule = torch.nn.Linear(self.hiddenDim,self.outputSize)
        self.tagVectors = torch.eye(self.outputSize)

    def forward(self, sentence: torch.tensor):
        wordEmbeddings = self.embeddingModule(sentence)
        lstm_ouput, hid = self.lstm(wordEmbeddings.view(len(sentence), 1, -1))
        tags = self.finalModule(lstm_ouput.view(len(sentence), -1))
        tag_scores = F.log_softmax(tags,dim=1)
        return tag_scores
    
    def getTagVectors(self, tags: torch.tensor):
        return self.tagVectors[tags]

def main():
    # take command line arguments
    NN = sys.argv[1]
    if NN != "-f" and NN != "-r":
        print("Invalid input, enter '-f' or '-r'")
        sys.exit()
    # print("started running...")
    inputSentence = input()
    # inputSentence = "The quick brown ,fox jumps! over the lazy dog."
    # lowercasing the input sentence
    inputSentence = inputSentence.lower()
    # tokenizing the input sentence
    inputSentence = RegexpTokenizer(r'\w+').tokenize(inputSentence)
    # print(inputSentence)
    randomTagSequence = ["RANDOM"] * len(inputSentence)
    data = [(inputSentence, randomTagSequence)]
    # print("data created")
    
    # print("vocabularies loaded")
    # set the device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    # -f
    if NN == "-f":
        # load model
        ffnModel = torch.load(bestFFNModel, map_location=torch.device(device))
        ffnModel.eval()
        # load vocabularies 
        wordVocab = torch.load("ffnTrainWordVocab.pth")
        tagVocab = torch.load("ffnTrainTagVocab.pth")
        # create a dataset
        myDataset = ffnDataset(data, ffnModel.p, ffnModel.s, wordVocab, tagVocab)
        # create a dataloader
        myDataLoader = DataLoader(myDataset, batch_size=1)
        # predict tags
        predTags = []
        for i, (x, y) in enumerate(myDataLoader):
            y_pred = ffnModel(x)
            y_tag_index = torch.argmax(y_pred , dim = 1)
            y_tag = [tagVocab.get_itos()[i.item()] for i in y_tag_index]
            predTags.extend(y_tag)
        # print the predicted tags
        for i in range(len(inputSentence)):
            print(inputSentence[i]+ '\t' + predTags[i])
    # - r
    if NN == "-r":
    # load model
        lstmModel = torch.load(bestLSTMModel,map_location=torch.device(device))
        lstmModel.eval()
        # load vocabularies 
        wordVocab = torch.load("lstmTrainWordVocab.pth")
        tagVocab = torch.load("lstmTrainTagVocab.pth")
        # create a dataset
        myDataset = lstmDataset(data,wordVocab,tagVocab)
        # create a dataloader
        myDataLoader = DataLoader(myDataset,batch_size=1)
        # predict tags
        for (sentence, tags) in myDataLoader:
            sentence = sentence[0]
            tags = tags[0]
            # move to device
            sentence = sentence.to(device)
            # tags = tags.to(device)
    # predict
        tag_scores = lstmModel(sentence)
        tagIndices = torch.argmax(tag_scores, dim=1)
        tagStrings = [tagVocab.get_itos()[i.item()] for i in tagIndices]
        # print predictions
        for i in range(len(inputSentence)):
            print(inputSentence[i],"\t",tagStrings[i])

if __name__ == "__main__":
    main()
