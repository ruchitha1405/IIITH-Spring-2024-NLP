import sys
import random
import math
import datetime
import pickle
import json
# import re
from tok import Tokenizer as tk
from queue import PriorityQueue as pq
from scipy.stats import linregress
import numpy as np
def getCorpusName(corpusPath):
        return corpusPath.split('/')[-1].split('.')[0]

def getModelPath(LMtype, corpusPath, n):
        return f'./models/{LMtype}/{getCorpusName(corpusPath)}/{n}Gram.json'

def getPickleModelPath(LMtype, corpusPath, n):
        return f'./models/{LMtype}/{getCorpusName(corpusPath)}/{n}Gram.pkl'

# save model
def saveModel(model, filename):
    with open(filename, 'wb') as file:
        pickle.dump(model, file)
    return

# load model
def loadModel(filename):
    with open(filename, 'rb') as file:
        model = pickle.load(file)
    return model

class N_Gram_Model:
    def __init__(self, corpusPath , n  , LMtype , modelPath = None):
        self.corpusPath = corpusPath
        self.n = n
        self.frequencies = {} # n-gram: frequency
        self.normalProbabilities = {} # n-gram: normal probability
        # self.gtProbabilities = {} # n-gram: gt probability
        # self.interpolatedProbabilities = {} # n-gram: interpolated probability
        self.LMtype = LMtype # based on the LM type, decision will be made on which probabilities to use
        self.modelPath = modelPath
        self.tokenizedCorpus = None
        self.trainData = None
        self.testData = None
        self.trainDataDictionary = None
        self.unkThreshold = 3
        self.trainDataWithUNK = None
        self.rStar = None # r* values for gt smoothing of 3-gram model
        self.lambda1 = None
        self.lambda2 = None
        self.lambda3 = None
        # self.uniNormalProb = {}
        # self.biNormalProb = {}
        # self.triNormalProb = {}
        self.uniGram = None
        self.biGram = None
        self.triGram = None
        self.negligibleProb = math.pow(10, -15)

    def readCorpusAndTokenize(self):
        # read the corpus and save it in a variable
        with open(self.corpusPath, 'r') as f:
            corpusText = f.read()
        # tokenize the corpus
        self.tokenizedCorpus = self.tokenize(corpusText)
    
    def tokenize(self,text):
        # tokenize the text
        tokenizer = tk()
        return tokenizer.Tokenize(text)

    def getTrainTestDataSets(self):
        # split the corpus into train and test sets
        random.seed(42)
        data = self.tokenizedCorpus
        random.shuffle(data)
        self.trainData = data[1000:]
        self.testData = data[:1000]

    def getTrainDataDictionary(self):
        # get the dictionary of the train data
        self.trainDataDictionary = self.getDataDictionary(self.trainData)
    
    def getTrainDataWithUNK(self):
        # replace the rare words with <unk>
        self.trainDataWithUNK = self.replaceRareWords(self.trainData , self.trainDataDictionary)

    def setUniGramBiGramTriGramModelsForInterpolation(self , uniGram , biGram , triGram):
        self.uniGram = uniGram
        self.biGram = biGram
        self.triGram = triGram
    
    def train(self):
        # train the model on the train set
        # calculate the frequencies and probabilities of all the n-grams
        self.calculateNgramFrequencies(self.trainDataWithUNK)
        if (self.LMtype == "n"):
            # 2. calculate the normal probabilities
            # self.getNormalProbabilities()
            pass
        if (self.LMtype == "g"):
            # 3. calculate the gt probabilities
            self.goodTuringSmoothing()
        if (self.LMtype == "i"):
            # calculate the interpolated probabilities
            self.interpolation()
        # 5. save the model
        # self.saveModel()
        return

    def calculateNgramFrequencies(self, dataWithUNK):
        n = self.n
        dataWithStartEndSymbols = self.addStartEndSymbols(dataWithUNK , n)
        for sentence in dataWithStartEndSymbols:
            for i in range((len(sentence) - n) + 1):
                ngram = tuple(sentence[i:i+n])
                if ngram in self.frequencies:
                    self.frequencies[ngram] += 1
                else:
                    self.frequencies[ngram] = 1
        return


    def getProbabilityOfUserInput(self , userInput):
        # get the probability of the text entered by the user
        # tokenize the user input
        tokens = self.tokenize(userInput)
        # # Flatten the 2D list using the sum function
        one_d_tokens = sum(tokens, [])
        # replace the rare words with <unk>
        replacedSentence = self.replaceRareWords([one_d_tokens] , self.trainDataDictionary)
        # add start and end symbols to the user input
        sentence = self.addStartEndSymbols([replacedSentence[0]] , self.n)[0]
        return math.exp(self.getLogProbabilityOfSentence(sentence))

    def getLogProbabilityOfSentence(self , sentence):
        # calculate the probability of the sentence
        initProbability = 1
        initLog = math.log(initProbability)
        logProbability = float(initLog)
        for i in range((len(sentence) - self.n) + 1):
            ngram = tuple(sentence[i:i+self.n])
            probability = self.getProbabilityOfNgram(ngram) # p(wn/w1...wn-1)
            logProbability += math.log(probability)
        return logProbability

    def getProbabilityOfNgram(self, ngram):
        # get the probability of the ngram depending on the LM type p(wn/w1...wn-1)
        if self.LMtype == "n":
            # if ngram not in self.frequencies:
            #     return self.negligibleProb
            # else:
            # get normal probability
            return self.getNormalProbabilityOfNgram(ngram)
        elif self.LMtype == "g":
            # get gt probability of the 3-gram
            if len(ngram) != 3:
                print("The gt probability is only supported for trigram model.")
                exit()
            return self.getGtProbabilityOfTrigram(ngram)
        elif self.LMtype == "i":
            # get interpolated probability of the 3-gram
            if len(ngram) != 3:
                print("The interpolated probability is only supported for trigram model.")
                exit()
            return self.getInterpolatedProbabilityOfTrigram(ngram)
    
    def evaluate(self , data):
        # evaluate the 3-gram model on the data set
        if (self.n != 3):
            print("The evaluation is only supported for 3-gram model.")
            exit()
        # calculate the perplexity of the every sentence in the data set
        # calculate the avg perplexity of the data set
        perplexity = {}
        for sentence in data:
            perplexity[tuple(sentence)] = self.perplexity(sentence)
        avgPerplexity = sum(perplexity.values()) /float(len(perplexity))
        return perplexity, avgPerplexity

    def perplexity(self, sentence):
        # calculate the perplexity of the sentence using the 3-gram model
        if (self.n != 3):
            print("The perplexity is only supported for 3-gram model.")
            exit()
        # replace the rare words with <unk>
        replacedSentence = self.replaceRareWords([sentence] , self.trainDataDictionary)
        # add start and end symbols to the user input
        newSentence = self.addStartEndSymbols([replacedSentence[0]] , self.n)[0]
        # probabilities = self.decideProbabilities() # based on the LM type
        logProbOfSentence = self.getLogProbabilityOfSentence(newSentence)
        numOfWordsIncludingEnd = len(newSentence)- 2
        # if probOfSentence == 0:
        #     print("The probability of the sentence is zero.", newSentence)
        #     exit()
        # if probOfSentence < 0:
        #     print("The probability of the sentence is negative.", newSentence)
        #     exit()
        return math.exp(logProbOfSentence * (-1 / float(numOfWordsIncludingEnd)))
    
    def getNormalProbabilityOfNgram(self , ngram):
        # calculate the normal probability p(Wn/W1...Wn-1)
        if ngram not in self.frequencies:
            return self.negligibleProb
        if (self.n == 1):
            denominator = 0
            for unigram in self.frequencies:
                denominator += self.frequencies[unigram]
            return self.frequencies[ngram] / float(denominator)
        denominator = 0
        for ngram2 in self.frequencies:
            if ngram[:-1] == ngram2[:-1]:
                denominator += self.frequencies[ngram2]
        if(denominator == 0): # it never happens
            print("denominator is zero while calculating the normal probability for ngram: " , ngram)
            exit()
        return self.frequencies[ngram] / float(denominator)

    def getAllNormalProbabilities(self):
        # calculate the normal probabilities p(Wn/W1...Wn-1) for all n-grams
        for ngram in self.frequencies:
            self.normalProbabilities[ngram] = self.getNormalProbabilityOfNgram(ngram)
        return

    def goodTuringSmoothing(self):
        # calculate the gtProbabilities p(w3/w1w2)
        # 1. calculate Nr's
        maxFreq = max(self.frequencies.values())
        freqOfFreq = np.zeros(maxFreq+1)
        for ngram in self.frequencies:
            freqOfFreq[self.frequencies[ngram]] += 1
        # 2. fit line to log(r) and log(Nr) for Nr > 0 to get log(Nr) = a + b * log(r)
        # take log(r) only for Nr > 0
        x = np.array([])
        y = np.array([])
        for r in range(1,maxFreq+1):
            if freqOfFreq[r] > 0:
                x = np.append(x, math.log(r))
                y = np.append(y, math.log(freqOfFreq[r]))
        line = linregress(x, y)
        a = line.intercept
        b = line.slope
        # 3. calculate r* = (r+1) * (S(Nr+1) / S(Nr)) for all r , S(Nr) = exp(a + b * log(r)) for given r
        # initialize rStar with float zeros
        self.rStar = np.zeros(maxFreq+1).astype(float)
        for r in range(0,maxFreq+1):
            self.rStar[r] = (r+1) * self.smoothedNr(r+1, a, b) / float(self.smoothedNr(r, a, b))
        # # 4. calculate the gt probabilities p(w3/w1w2) where freq(w1w2w3) > 0
        # for ngram in self.frequencies:
        #     self.gtProbabilities[ngram] = self.getGtProbabilityOfTrigram(ngram)
        
    def getGtProbabilityOfTrigram(self , trigram):
        # calculate the gt probability P(w3/w1w2)
        if trigram not in self.frequencies:
            count = 0
        else :
            count = self.frequencies[trigram]
        countStar = self.rStar[count] # Count*(w1w2w3)
        denominator = 0 # sum of all countStar's for w1w2wi where i is in the vocabulary
        for word in self.trainDataDictionary:
            newTriGram = tuple([trigram[0],trigram[1],word])
            if newTriGram in self.frequencies:
                # r > 0
                r = self.frequencies[newTriGram]
                denominator += self.rStar[r]
            else:
                # r = 0
                denominator += self.rStar[0]
        if denominator == 0:
            print("The denominator is zero while calculating the gt probability for trigram: " , trigram)
            exit()
        return countStar / float(denominator)
        
    def smoothedNr(self, r, intercept, slope):
        # calculate the smoothed Nr
        if r == 0:
            return 1
        return math.exp(intercept + slope * math.log(r))

    def interpolation(self ):
        # calculate the interpolatedProbabilities of the 3-gram model p(w3/w1w2)
        # train the unigram, bigram and trigram models
        self.uniGram.trainDataWithUNK = self.trainDataWithUNK
        self.uniGram.train()
        self.biGram.trainDataWithUNK = self.trainDataWithUNK
        self.biGram.train()
        # self.triGram.train()
        self.triGram = self
        # self.uniNormalProb = uniNormalProb
        # self.biNormalProb = biNormalProb
        # self.triNormalProb = triNormalProb
        if (self.n != 3):
            print("The interpolation is only supported for trigram model.")
            exit()
        self.lambda1, self.lambda2, self.lambda3 = self.getLambdasOfTrigramInterpolation()
        # for trigram in self.frequencies:
        #     self.interpolatedProbabilities[trigram] = self.getInterpolatedProbabilityOfTrigram(trigram , self.lambda1, self.lambda2, self.lambda3 , uniNormalProb, biNormalProb, triNormalProb)
        return

    def getInterpolatedProbabilityOfTrigram(self , trigram):
        # calculate the interpolated probability P(w3/w1w2)
        bigram = tuple(trigram[1:3])
        unigram = tuple([trigram[2]])
        uniNormProb = self.uniGram.getNormalProbabilityOfNgram(unigram)
        biNormProb = self.biGram.getNormalProbabilityOfNgram(bigram)
        triNormProb = self.triGram.getNormalProbabilityOfNgram(trigram)
        # if uniProb == 0:
        #     uniProb = self.negligibleProb
        # if biProb == 0:
        #     biProb = self.negligibleProb
        # if triProb == 0:
        #     triProb = self.negligibleProb
        return self.lambda1 * uniNormProb + self.lambda2 * biNormProb + self.lambda3 * triNormProb

    def getLambdasOfTrigramInterpolation(self):
        # calculate the lambdas for the trigram interpolation
        lambda1 = lambda2 = lambda3 = 0
        uniFreq = self.uniGram.frequencies
        biFreq = self.biGram.frequencies
        triFreq = self.triGram.frequencies
        x = [0, 0, 0]
        for triGram in self.frequencies:
            uniTuple = tuple([triGram[2]])
            uniNormalProb = self.uniGram.getNormalProbabilityOfNgram(uniTuple)
            denominator0 = float((uniFreq[uniTuple]/uniNormalProb) - 1)
            if denominator0 == 0:
                x[0] = 0
            else:
                x[0] = (uniFreq[uniTuple] - 1)/denominator0
            biTuple = tuple(triGram[1:3])
            biNormalProb = self.biGram.getNormalProbabilityOfNgram(biTuple)
            denominator1 = float((biFreq[biTuple]/biNormalProb) - 1)
            if denominator1 == 0:
                x[1] = 0
            else:
                x[1] = (biFreq[biTuple] - 1)/denominator1
            triNormalProb = self.triGram.getNormalProbabilityOfNgram(triGram)
            denominator2 = float((triFreq[triGram]/triNormalProb) - 1)
            if denominator2 == 0:
                x[2] = 0
            else:
                x[2] = (triFreq[triGram] - 1)/denominator2
            maxIndex = x.index(max(x))
            if maxIndex == 0:
                lambda1 += triFreq[triGram]
            elif maxIndex == 1:
                lambda2 += triFreq[triGram]
            elif maxIndex == 2:
                lambda3 += triFreq[triGram]
        # normalize the lambdas
        total = float(lambda1 + lambda2 + lambda3)
        lambda1 = lambda1 / total
        lambda2 = lambda2 / total
        lambda3 = lambda3 / total   
        return lambda1, lambda2, lambda3

    def getDataDictionary(self, data):
        # get the dictionary of the data which is already tokenized
        dic = {}
        for sentence in data:
            for word in sentence:
                if word in dic:
                    dic[word] += 1
                else:
                    dic[word] = 1
        return dic
    
    def replaceRareWords(self , data , dictionary):
        # replace the rare words with <unk>
        threshold = self.unkThreshold
        dataWithUNK = data.copy()
        for sentence in range(len(dataWithUNK)):
            for word in range(len(dataWithUNK[sentence])):
                if dataWithUNK[sentence][word] not in dictionary or dictionary[dataWithUNK[sentence][word]] < threshold:
                    dataWithUNK[sentence][word] = '<UNK>'
        return dataWithUNK
    
    def addStartEndSymbols(self , data , n):
        # add start and end symbols to the data
        dataWithStartEndSymbols = data.copy()
        for sentence in range(len(data)):
            for i in range(n-1):
                dataWithStartEndSymbols[sentence].insert(0 , '<START>')
            dataWithStartEndSymbols[sentence].append('<END>')
            if n == 1:
                dataWithStartEndSymbols[sentence].insert(0 , '<START>')
        return dataWithStartEndSymbols
    
    def generateNextWord(self , initialWords , numOfCandidatesOfNextWord):
        # # generate next word using the probabilities obtained upon training
        # probabilities = self.decideProbabilities()
        text = initialWords
        n = self.n
        # tokenize the initial words
        tokens = self.tokenize(initialWords)
        # # Flatten the 2D list using the sum function
        one_d_tokens = sum(tokens, [])
        replacedSentence = self.replaceRareWords([one_d_tokens] , self.trainDataDictionary)
        # add start and end symbols to the user input
        sentence = self.addStartEndSymbols([replacedSentence[0]] , n)[0]
        # last sentence 
        context = sentence[(-n)+1:]
        
        probabilitiesOfNextWord  = pq()
        # get the possibilities of next word
        if self.LMtype == "n": # normal probability
            for word in self.trainDataDictionary:
                ngram = tuple(context + [word])
                probability = self.getNormalProbabilityOfNgram(ngram)
                probabilitiesOfNextWord.put((-probability, word))
            word = '<UNK>'
            ngram = tuple(context + [word])
            probability = self.getNormalProbabilityOfNgram(ngram)
            probabilitiesOfNextWord.put((-probability, word))
        if self.LMtype == "g": # gt probability
            for word in self.trainDataDictionary:
                ngram = tuple(context + [word])
                probability = self.getGtProbabilityOfTrigram(ngram)
                probabilitiesOfNextWord.put((-probability, word))
            word = '<UNK>'
            ngram = tuple(context + [word])
            probability = self.getGtProbabilityOfTrigram(ngram)
            probabilitiesOfNextWord.put((-probability, word))
        if self.LMtype == "i": # interpolated probability
            for word in self.trainDataDictionary:
                ngram = tuple(context + [word])
                probability = self.getInterpolatedProbabilityOfTrigram(ngram)
                probabilitiesOfNextWord.put((-probability, word))
            word = '<UNK>'
            ngram = tuple(context + [word])
            probability = self.getInterpolatedProbabilityOfTrigram(ngram)
            probabilitiesOfNextWord.put((-probability, word))
        # probabilitiesOfNextWord  = pq()
        # for ngram in probabilities:
        #     if ngram[:-1] == tuple(context):
        #         probabilitiesOfNextWord.put((-probabilities[ngram], ngram[-1]))
        # get the top numOfCandidatesOfNextWord candidates
        candidates = []
        while not probabilitiesOfNextWord.empty() and len(candidates) < numOfCandidatesOfNextWord:
            candidate = probabilitiesOfNextWord.get()
            probability = -candidate[0]
            word = candidate[1]
            candidates.append([word , probability])
        if len(candidates) < numOfCandidatesOfNextWord:
            candidates.append(['<UNK>' , 'NEXT BEST CHOICE'])
        return candidates

# take command line arguments
commandLineLMtype = sys.argv[1]
commandLineCorpusPath = sys.argv[2]
# only i,n,g types are allowed
if commandLineLMtype not in ["i","n","g"]:
    print("Invalid language model type")
    sys.exit()

# load model 
triGramModel = loadModel(getPickleModelPath(commandLineLMtype,commandLineCorpusPath , 3))

# User Prompt
while True:
    try :
        inputSentence = input("input sentence: ")
        if(inputSentence == ""):
            raise Exception("Empty input!")
        print("score: ", triGramModel.getProbabilityOfUserInput(inputSentence))
    except Exception as e:
        print(e)
        print("Please enter a valid sentence")
    finally:
        print("Do you want to continue? (y/n)")
        if(input() == 'n'):
            break