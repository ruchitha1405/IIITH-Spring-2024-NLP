## 1. Tokenization:
- run `python3 tokenizer.py` 
- enter the text you want to tokenize

## 2. language model:
- run `python3 language_model.py <lm_type> <corpus_path>`
- enter the sentence for which you want to get the probability

## 3. Generation:
- run `python3 generator.py <lm_type> <corpus_path> <k>`
- enter the sentence for which you want to generate the next word

## lm_type:
- "n" : with no smoothing
- "i" : with interpolation
- "g" : with good turing

## Generation Experiment:
outOfDataScenario(OOD) = Later, the boy saw a real wolf sneaking around his flock. Alarmed, he jumped on his feet and cried out as loud as he could, “Wolf! Wolf!” But the villagers thought he was fooling them again, and they didn’t come to help.

At sunset, the villagers went looking for the boy who hadn’t returned with their sheep. When they went up the hill, they found him weeping.

“There was a wolf here! The flock is gone! I cried out, ‘Wolf!’ but you didn’t come,” he wailed.

An older man went to comfort the boy. As he put his arm around him, he said, “Nobody believes a liar, even when he is telling the truth!”

### Results
- Test results and train results have very high differences in perplexity because this is a very simple model. It can't be generalized to train set so easily.
- The valid perplexities have been put in the report and the text files.