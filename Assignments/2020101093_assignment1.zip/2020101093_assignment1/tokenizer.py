import tok 

# Take input from user

while True:
    try :
        userInput = input("your text: ")
        if(userInput == ""):
            raise ValueError("Empty String")
        tk = tok.Tokenizer()
        tokens = tk.Tokenize(userInput)
        print("tokenized text: ",tokens)
    except ValueError as e:
        print("ValueError: ", e)
        print("Please enter a valid sentence")
    except Exception as e:
        print("Exception: ", e)
        print("Please enter a valid sentence")
    finally:
        print("Do you want to continue? (y/n)")
        if(input() == 'n'):
            break