import sys
import math
from tokenizer import Tokenizer as tk
from language_model import N_Gram_Model as ngm
import pickle

def getCorpusName(corpusPath):
        return corpusPath.split('/')[-1].split('.')[0]

def getPickleModelPath(LMtype,corpusPath,n):
        return f'./models/{LMtype}/{getCorpusName(corpusPath)}/{n}Gram.pkl'

class Generator:
    def __init__(self,lmType, corpusPath, k , n , modelPath = None):
        self.lmType = lmType
        self.corpusPath = corpusPath
        self.numCandidates = k
        self.n = n
        self.modelPath = modelPath
        self.loadedModel = None
    
    def loadModel(self):
        if self.modelPath is None:
            print("Model path is not provided, therefore cannot load the model")
            return
        with open(self.modelPath, 'rb') as file:
            self.loadedModel = pickle.load(file)

    def generate(self, initialWords):
        candidates = self.loadedModel.generateNextWord(initialWords ,self.numCandidates)
        return candidates
    
    def printCandidates(self, candidates):
        for candidate in candidates:
            print(candidate[0] + '\t' + candidate[1])
        return

# Take input from user
lmType = sys.argv[1]
corpusPath = sys.argv[2]
k = sys.argv[3]
n = 3
# corpus = "pride"
# modelPath = "models/" + lmType + n + corpus + ".txt"
gen = Generator(lmType, corpusPath, k, n, getPickleModelPath(lmType, corpusPath, n))
# load the model
gen.loadModel()
# genModel = gen.loadedModel

while True:
    try:
        initialText = input("input sentence: ")
        if initialText == "":
            raise ValueError("input sentence cannot be empty")
        # generate the text
        candidates = gen.generate(initialWords=initialText)
        # print the candidates
        print("output:")
        gen.printCandidates(candidates)
    except ValueError as e:
        print(e)
    except Exception as e:
        print(e)
    finally:
        print("Do you want to continue? (y/n)")
        if input() == "n":
            break