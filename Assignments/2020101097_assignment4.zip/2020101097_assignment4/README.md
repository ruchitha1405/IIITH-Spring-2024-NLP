
To run nli model:
   $python3 ELMO.py

To run sst model:
   $python3 ELMO2.py



models:
(Required to place in same folder as .py files)
pretrained.pth contains pretrained model on nli
pretrained1.pth contains pretrained model on sst
sen_class1.pth
sen_class2.pth

Models and reports location:
https://drive.google.com/drive/folders/1M0RKDwd6D0LpNnI3UuusgRvVOxMVA2YU?usp=share_link
